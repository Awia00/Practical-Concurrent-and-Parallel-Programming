package ABC;

import java.io.Serializable;

/**
 * Created by AndersWindSteffensen on 2016-12-04.
 */
public class PrintBalanceMessage implements Serializable {
}
